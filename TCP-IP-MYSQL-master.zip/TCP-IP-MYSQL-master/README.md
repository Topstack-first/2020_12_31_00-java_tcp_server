# TCP-IP-MYSQL
Connect multiple devices on a server using tcp-ip connection
Multiple Client can send data on server using IP address and Port number
Data of each client is  saved in MySQL database with unqique ID send by Clients
